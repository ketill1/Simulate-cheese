function E_tot=energy_ost()


E_tot=E_k+E_p+E_s; %total energy